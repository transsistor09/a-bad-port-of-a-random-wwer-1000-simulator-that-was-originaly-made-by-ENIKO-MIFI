..\..\BIN\giw -2 vvr_5l.cfg

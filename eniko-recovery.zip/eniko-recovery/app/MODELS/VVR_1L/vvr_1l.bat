..\..\BIN\giw -2 vvr_1l.cfg

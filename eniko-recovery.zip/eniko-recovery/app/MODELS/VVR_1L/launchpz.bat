..\..\BIN\pz.exe ..\..\BIN\pz.cfg
